🕸# Tourism-Management-System💻

   _______________________Installation Steps(Configuration)______________________
1. Download and Unzip file on your local system.
2.Copy tms folder and tms folder inside root directory (for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/html)

   _____________________________Database Configuration_________________________

Open phpmyadmin
Create Database tms
Import database tms.sql (available inside zip package)Open Your browser put inside browser  👇🏻
👉🏻 http://localhost/tms


   ///////////////\\\\\\\\\\\\\\\\\\\///////////\\\\\\\\\\\\\\\\\
Login Details for admin : 
Open Your browser put inside browser 👉🏻 http://localhost/tms/admin 

Username : admin

Password : Test@123

   /////////\\\\\\\\\\\\\\////////////\\\\\\\\\\\\\\\\\\\

Login Details for user: 
Open Your browser put inside browser  👉🏻 http://localhost/tms/

Username : anuj@gmail.com

Password : Test@123

  |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||
                                 👇🏻

_________________________Screen Short_______________________
![Screenshot 2022-03-08 at 8 03 04 PM](https://user-images.githubusercontent.com/54598380/157259105-06bf9333-74a6-434c-9c75-f409957e7a8a.png)
![Screenshot 2022-03-08 at 8 02 31 PM](https://user-images.githubusercontent.com/54598380/157259124-6b5dc12a-5fca-420e-9dca-e26ab1234718.png)
![Screenshot 2022-03-08 at 8 02 23 PM](https://user-images.githubusercontent.com/54598380/157259131-7739c156-e542-4e23-8f32-63e8d356e602.png)
![Screenshot 2022-03-08 at 8 02 13 PM](https://user-images.githubusercontent.com/54598380/157259136-bf10adaf-c641-4743-8cc1-fc6a2414d4d4.png)
![Screenshot 2022-03-08 at 8 07 26 PM](https://user-images.githubusercontent.com/54598380/157259740-70228ad8-0b42-4c97-99a8-e678954076ac.png)
![Screenshot 2022-03-08 at 8 07 35 PM](https://user-images.githubusercontent.com/54598380/157259746-a37391f8-405d-41ec-a07b-be540f60e6f4.png)
